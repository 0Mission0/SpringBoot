insert into account values(1,'root', 'root');
insert into account values(2,'mission', 'mission');

insert into authority values('root', 'ROLE_ADMIN');
insert into authority values('mission', 'ROLE_USER');